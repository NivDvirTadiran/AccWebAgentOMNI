import {
  Component,
  ViewEncapsulation,
  HostBinding,
  Input,
} from "@angular/core";

import { StatusSwitcherWithIcon } from "../StatusSwitcherWithIcon/status-switcher-with-icon.component";
@Component({
  selector: "widget-pie-chart",
  standalone: true,
  encapsulation: ViewEncapsulation.None,
  imports: [StatusSwitcherWithIcon],
  templateUrl: "./widget-pie-chart.component.html",
  styleUrls: ["./widget-pie-chart.component.css"],
})
export class WidgetPieChart {
  @HostBinding("style.display") display = "contents";

  constructor() {}

  /** Variant props */
  @Input() property1: 2 = 1;
  @Input() state: string = "Default";
}
