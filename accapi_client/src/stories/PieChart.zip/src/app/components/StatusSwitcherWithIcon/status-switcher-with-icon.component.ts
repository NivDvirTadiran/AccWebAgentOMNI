import {
  Component,
  ViewEncapsulation,
  HostBinding,
  Input,
} from "@angular/core";

import { CommonModule } from "@angular/common";
@Component({
  selector: "status-switcher-with-icon",
  standalone: true,
  encapsulation: ViewEncapsulation.None,
  imports: [CommonModule],
  templateUrl: "./status-switcher-with-icon.component.html",
  styleUrls: ["./status-switcher-with-icon.component.css"],
})
export class StatusSwitcherWithIcon {
  @HostBinding("style.display") display = "contents";

  constructor() {}

  /** Value props */
  @Input() prop: string = "";
  @Input() iconStatus: string = "";
  /** Variant props */
  @Input() state: string = "Default";
  @Input() type: string = "Default";
  /** Style props */
  @Input() statusSwitcherWithIconWidth: string | number = "";
  @Input() divFontSize: string | number = "";
  @Input() divFontFamily: string | number = "";

  get statusSwitcherWithIconStyle() {
    return {
      width: this.statusSwitcherWithIconWidth,
    };
  }

  get divStyle() {
    return {
      "font-size": this.divFontSize,
      "font-family": this.divFontFamily,
    };
  }
}
